# Don't manually change, let poetry-dynamic-versioning handle it.
__version__ = "0.0.0-post.19+4cd44ac"

__all__ = []
